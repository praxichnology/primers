# Companion Casebook Answer Key

> **These answers reproduce synthetic instructional examples. They are not research findings or empirical evidence.**

## Lesson 0 — Known-answer demonstration

First-Head sequences are HH and HT. Both have Best Toss = 1, so the expected Best Toss is **1.000**. First-Tail sequences are TH and TT, with Best Toss values 1 and 0, so the expected value is **0.500**. The expected signed difference is therefore **0.500**.

**Bounded conclusion:** The positive response is produced by the rules: Toss 1 creates the labels and remains eligible to determine Best Toss. The coin is fair, the tosses are independent, and no learning is possible.

## Lesson 1 — Distributional control

The Red mean is **64.900** and the Blue mean is **64.600**, giving an observed signed difference of **0.300**.

The construction warrants an expected center of zero because group assignment is independent of scores and exchanging the group names reverses the sign without changing the score process. It does not require this finite sample to return exactly 0.000.

**Status:** Behaved as specified.

**Bounded conclusion:** The observed 0.300-point gap is a finite realization near the construction's zero center. This generated table does not test the game's logging, storage, filtering, or group-construction code.

## Lesson 2 — Label permutation

The observed A mean is **76.750** and the B mean is **65.750**, producing a signed difference of **11.000**. There are `8 choose 4 = 70` assignments that preserve the four-versus-four group sizes. Two assignments produce an absolute gap at least as large as 11.000, so the exact two-sided probability is **2/70 = 0.02857142857142857**.

**Status:** Requires investigation.

**Bounded conclusion:** Under the stated exchangeability condition, an 11-point absolute gap is unusual as label arrangement alone. That does not identify an actor mechanism, establish causality, or test upstream application behavior.

## Lesson 3 — Enacted no-mechanism control

Using Best Run across all three runs, the Early-High values are 72, 68, 70, and 66, with a mean of **69.000**. The Early-Low values are 58, 62, 64, and 61, with a mean of **61.250**. The signed gap is **7.750**.

The contrast isolates the rule coupling. Later-only Best Run has a mean of **60.750** in both groups, and Last Run has a mean of **59.750** in both groups. Both signed gaps are **0.000**. All **24** records reach every declared checkpoint.

The complete-record pipeline fixture creates and retains three scores—52, 61, and 67—and reproduces their mean of **60.000**. The deliberately failing fixture creates three records but retains only two, changing the analyzed mean to **56.500**. Its one-record shortfall requires investigation.

**Status:** Characterized for the primary fixture; behaved as specified for `03a`; deliberately requires investigation for `03b`.

**Bounded conclusion:** The 7.750-point reading is built into reusing Run 1 for grouping and Best Run in this fixture. It is not a universal null expectation and not an amount to subtract. The supporting pipeline files have derivable answers, but only processing them through a declared application path can test that path. A genuine enacted condition must run the actor through the application.

## Lesson 4 — Analyst-choice sensitivity

| Run 1 cutoff | Early-High n | Early-Low n | Early-High mean Best | Early-Low mean Best | Signed gap |
|---:|---:|---:|---:|---:|---:|
| 60 | 6 | 4 | 76.333 | 71.000 | **+5.333** |
| 65 | 4 | 6 | 73.500 | 74.667 | **−1.167** |
| 70 | 2 | 8 | 72.500 | 74.625 | **−2.125** |

**Status:** Requires design-based resolution.

**Bounded conclusion:** The sign of the comparison depends on the prespecified cutoff. The cutoff must be resolved from the construct and design, not chosen from the most favorable cell. These three cells are neither a null distribution nor three independent replications.
