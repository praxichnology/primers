#!/usr/bin/env python3
"""Recompute the synthetic companion-casebook results and check golden values."""

from __future__ import annotations

import itertools
import json
import math
from pathlib import Path
from statistics import mean
from typing import Any


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
REQUIRED_PROVENANCE = {
    "schema_version", "case_id", "title", "status", "research_data",
    "empirical_evidence", "family", "purpose",
}


def read_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    missing = REQUIRED_PROVENANCE - value.keys()
    if missing:
        raise ValueError(f"{path.name}: missing required fields {sorted(missing)}")
    if (
        value["research_data"] is not False
        or value["empirical_evidence"] is not False
        or value["status"] != "synthetic_worked_example"
    ):
        raise ValueError(f"{path.name}: synthetic-data status is not explicit")
    return value


def known_answer() -> dict[str, float]:
    case = read_json(DATA / "00_two_toss_known_answer.json")
    groups: dict[str, list[tuple[float, float]]] = {"First-Head": [], "First-Tail": []}
    for row in case["sequences"]:
        groups[row["group"]].append((row["best_toss"], row["probability"]))
    values = {}
    for group, rows in groups.items():
        total_probability = sum(weight for _, weight in rows)
        values[group] = sum(value * weight for value, weight in rows) / total_probability
    return {
        "first_head_expected_best": values["First-Head"],
        "first_tail_expected_best": values["First-Tail"],
        "expected_signed_difference": values["First-Head"] - values["First-Tail"],
    }


def distributional() -> dict[str, float | int]:
    case = read_json(DATA / "01_distributional_control.json")
    red = [row["score"] for row in case["records"] if row["group"] == "Red"]
    blue = [row["score"] for row in case["records"] if row["group"] == "Blue"]
    return {
        "red_n": len(red), "blue_n": len(blue),
        "red_mean": mean(red), "blue_mean": mean(blue),
        "observed_signed_difference": mean(red) - mean(blue),
        "expected_center": 0.0,
    }


def label_permutation() -> dict[str, float | int]:
    case = read_json(DATA / "02_label_permutation.json")
    records = case["records"]
    outcomes = [row["outcome"] for row in records]
    a_indices = {i for i, row in enumerate(records) if row["label"] == "A"}
    a_n = len(a_indices)
    observed = mean(outcomes[i] for i in a_indices) - mean(
        outcomes[i] for i in range(len(outcomes)) if i not in a_indices
    )
    distribution = []
    for chosen in itertools.combinations(range(len(outcomes)), a_n):
        chosen_set = set(chosen)
        distribution.append(
            mean(outcomes[i] for i in chosen_set)
            - mean(outcomes[i] for i in range(len(outcomes)) if i not in chosen_set)
        )
    extreme = sum(abs(value) >= abs(observed) - 1e-12 for value in distribution)
    return {
        "a_n": a_n, "b_n": len(outcomes) - a_n,
        "observed_signed_difference": observed,
        "assignments_enumerated": len(distribution),
        "as_or_more_extreme": extreme,
        "exact_two_sided_probability": extreme / len(distribution),
    }


def enacted() -> dict[str, Any]:
    case = read_json(DATA / "03_enacted_no_mechanism.json")
    by_actor: dict[str, list[dict[str, Any]]] = {}
    for row in case["records"]:
        by_actor.setdefault(row["actor_id"], []).append(row)
    high_best, low_best = [], []
    high_later_best, low_later_best = [], []
    high_last, low_last = [], []
    for rows in by_actor.values():
        ordered = sorted(rows, key=lambda row: row["run_number"])
        best = max(row["score"] for row in ordered)
        later_best = max(row["score"] for row in ordered[1:])
        last = ordered[-1]["score"]
        if ordered[0]["score"] >= 65:
            high_best.append(best); high_later_best.append(later_best); high_last.append(last)
        else:
            low_best.append(best); low_later_best.append(later_best); low_last.append(last)
    checkpoint_names = ("logged", "stored", "retained", "analyzed", "reported")
    checkpoint_counts = {
        name: sum(bool(row["checkpoints"][name]) for row in case["records"])
        for name in checkpoint_names
    }
    return {
        "actor_count": len(by_actor), "run_count": len(case["records"]),
        "early_high_n": len(high_best), "early_low_n": len(low_best),
        "early_high_mean_best": mean(high_best),
        "early_low_mean_best": mean(low_best),
        "best_run_signed_difference": mean(high_best) - mean(low_best),
        "later_only_best_signed_difference": mean(high_later_best) - mean(low_later_best),
        "last_run_signed_difference": mean(high_last) - mean(low_last),
        "checkpoint_counts": checkpoint_counts,
    }


def pipeline_fixture(filename: str) -> dict[str, Any]:
    case = read_json(DATA / filename)
    completed = [row for row in case["records"] if row["completed"]]
    retained = [row for row in completed if row["retained"]]
    return {
        "created_records": len(completed), "retained_records": len(retained),
        "complete_mean": mean(row["score"] for row in completed),
        "retained_mean": mean(row["score"] for row in retained),
        "record_shortfall": len(completed) - len(retained),
    }


def sensitivity() -> dict[str, Any]:
    case = read_json(DATA / "04_analyst_choice_sensitivity.json")
    cells = []
    for cutoff in case["construction"]["prespecified_cutoffs"]:
        high = [max(row["runs"]) for row in case["actors"] if row["runs"][0] >= cutoff]
        low = [max(row["runs"]) for row in case["actors"] if row["runs"][0] < cutoff]
        cells.append({
            "cutoff": cutoff, "early_high_n": len(high), "early_low_n": len(low),
            "early_high_mean_best": mean(high), "early_low_mean_best": mean(low),
            "signed_difference": mean(high) - mean(low),
        })
    return {"cells": cells}


def equivalent(actual: Any, expected: Any) -> bool:
    if isinstance(actual, dict) and isinstance(expected, dict):
        return actual.keys() == expected.keys() and all(
            equivalent(actual[key], expected[key]) for key in actual
        )
    if isinstance(actual, list) and isinstance(expected, list):
        return len(actual) == len(expected) and all(
            equivalent(a, e) for a, e in zip(actual, expected)
        )
    if isinstance(actual, (int, float)) and isinstance(expected, (int, float)):
        return math.isclose(float(actual), float(expected), rel_tol=1e-12, abs_tol=1e-12)
    return actual == expected


def main() -> int:
    actual = {
        "GD-KNOWN-01": known_answer(),
        "GD-DIST-01": distributional(),
        "GD-PERM-01": label_permutation(),
        "GD-ENACT-01": enacted(),
        "GD-PIPE-OK-01": pipeline_fixture("03a_pipeline_known_answer.json"),
        "GD-PIPE-FAIL-01": pipeline_fixture("03b_pipeline_dropped_record_failure.json"),
        "GD-SENS-01": sensitivity(),
    }
    with (ROOT / "expected-results.json").open(encoding="utf-8") as handle:
        expected = json.load(handle)
    print(json.dumps(actual, indent=2, sort_keys=True))
    if not equivalent(actual, expected):
        print("ERROR: recomputed results differ from expected-results.json")
        return 1
    print("Verified: all synthetic casebook calculations match their golden values.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
