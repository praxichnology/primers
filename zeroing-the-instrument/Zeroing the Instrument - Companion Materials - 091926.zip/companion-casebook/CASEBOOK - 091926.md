# Garden Defense: A Worked Null-Control Case Study

> **Synthetic instructional example — no human participants, no research data, and no empirical evidence.**

## Case study box — When “user-generated data” look wrong

> A professor and graduate assistant build an online practice environment to study help-seeking and learning. With AI assistance, they add event logging and a dashboard. They think of the resulting records as *user-generated data*: learners answer questions, request hints, and earn scores; the software records what they do.
>
> When the first results appear, something seems off. Learners with more `hint_viewed` events have lower final scores. The team initially wonders whether requesting hints marks weak understanding, or whether the hints themselves are ineffective.
>
> They then inspect the path between learner action and reported finding. The hint panel automatically appears after two incorrect responses, and the software records that display as `hint_viewed` even when the learner never requests or reads the hint. The scoring rule also deducts points for those same incorrect responses. Consequently, two errors both place a learner in the “more hints viewed” group and lower the outcome used to compare that group. Every component may be working exactly as designed, yet the resulting association can appear without help-seeking causing poorer performance—and even without the learner choosing to seek help.
>
> The phrase *user-generated data* was not entirely wrong: learner actions began the process. It was incomplete. The reported pattern was produced through learner responses, the automatic hint trigger, the event definition, the scoring rule, and the later group comparison.
>
> **Open the box:** Does `hint_viewed` mean that a learner requested help, that the software displayed help, or merely that a logging condition fired? Could an actor that never chooses a hint still enter the “more hints viewed” group? Does the same action help create both the group label and the outcome? What no-mechanism condition would let the team observe what this arrangement reports without learner help-seeking?

### How to map the argument

The problem becomes easier to inspect when its parts are named:

- **Claim being considered:** Learners who voluntarily seek more hints show weaker understanding.
- **Observation:** More `hint_viewed` events are associated with lower final scores.
- **Warrant:** `hint_viewed` represents voluntary learner help-seeking, and the software has not created the relationship between that record and the score.
- **Rival explanation:** Two incorrect responses automatically create a `hint_viewed` event and also lower the score, even when the learner never requests help.
- **Fitted check:** Send an actor that makes a specified set of errors but never requests a hint through the implemented application. Check which hint events are recorded, how the actor is grouped, and what score reaches the report.
- **Bounded conclusion:** This check can show whether the implemented arrangement produces the association without voluntary help-seeking. It cannot establish whether requesting or receiving hints helps human learners.

The warrant is the easily missed part: it is the reason the observation is allowed to count as evidence for the claim. Opening the software path exposes assumptions inside that warrant that the phrase *user-generated data* had hidden.

## The running case

*Garden Defense* is a fictional lane-based game. Players place defenses while waves of pests approach a garden. Each run produces a score from 0 to 100, and players may complete several runs. A research team wants to use the game's records to compare groups and discuss repeated performance.

The lessons do not decide whether the fictional game works. They show what different checks can reveal about the machinery that turns actions into a reported result.

For every lesson, map the argument before calculating:

1. What claim or interpretation is being examined?
2. What recorded or computed observation is being offered as evidence?
3. What warrant must hold for that observation to support the claim?
4. What rival explanation or objection is the check built to address?
5. Which stages of the action-to-report path does the check traverse?
6. What comparison is warranted by the check, and what would an unexpected result require the team to do?
7. What bounded conclusion is permitted, and what remains outside it?

## Lesson 0 — Establish a known answer

**File:** `data/00_two_toss_known_answer.json`

The report's two-toss example contains four equally likely sequences. Toss 1 creates the group label; Best Toss is the maximum of Toss 1 and Toss 2.

Before calculating, predict whether the First-Head and First-Tail groups should have the same expected Best Toss. Then compute each group mean and the signed difference.

**Learning objective:** Show that a fair, independent process can produce a non-zero null response when the assigning observation remains inside the outcome.

## Lesson 1 — Distributional control

**File:** `data/01_distributional_control.json`

Both groups draw from the same illustrative score process, and Red/Blue labels are assigned independently of score. The statistic is the signed difference `mean(Red) - mean(Blue)`.

Calculate the two sample means and their difference. Then distinguish the finite sample result from the expected center warranted by the construction.

**Learning objective:** Separate “expected to be centered at zero” from “every finite sample must equal zero.”

**Inspection question:** Which application stages were bypassed when the table was supplied directly to the analysis?

## Lesson 2 — Label permutation

**File:** `data/02_label_permutation.json`

Eight fixed outcomes carry four A and four B labels. The labels were assigned independently, and both groups received the same illustrative experience. Enumerate every assignment of four A labels among the eight outcomes while preserving group sizes.

Compute the observed signed gap, the exact two-sided permutation probability, and the action the team should take.

**Learning objective:** Use permutation only when the labels are exchangeable under the condition being tested.

**Counterexample:** Early-High and Early-Low labels derived from Run 1 are not exchangeable with Best Run when Run 1 remains eligible to determine Best Run. Shuffling those labels would destroy the relationship the control needs to preserve.

## Lesson 3 — Enacted no-mechanism control

**Primary fixture:** `data/03_enacted_no_mechanism.json`  
**Pipeline fixtures:** `data/03a_pipeline_known_answer.json` and `data/03b_pipeline_dropped_record_failure.json`

Eight memoryless actors each complete three runs. Apply the rule `Early-High when Run 1 >= 65`; classify the remaining actors as Early-Low. First calculate Best Run across all three runs, including Run 1. Then recompute the gap using later-only Best Run and Last Run.

Every primary-fixture record carries checkpoints for logging, storage, retention, analysis, and reporting. The two small pipeline fixtures contain the same three completed scores. One retains all three; the deliberately failing fixture drops the score of 67 before analysis. Compare each retained count and mean with the derivable answer.

**Learning objectives:** Identify the built-in effect of reusing Run 1, and distinguish calculation verification from enactment through a real application.

**Scope boundary:** A loaded JSON fixture is not itself an enacted control. It becomes an integration check only when the application processes it through the declared path. A genuine enacted control requires the application to run the actor and export the resulting traces. A memoryless random actor can test that traversed path without becoming a model of people.

## Lesson 4 — Analyst-choice sensitivity

**File:** `data/04_analyst_choice_sensitivity.json`

Hold all actor records fixed. Apply the three prespecified Run 1 cutoffs—60, 65, and 70—with ties assigned to Early-High. Calculate the Early-High minus Early-Low Best Run gap for each cell.

Compare the signs and magnitudes. Do not calculate a null probability from these three cells and do not choose the cutoff that gives the preferred conclusion.

**Learning objective:** Recognize conclusion dependence on an analyst choice without mislabelling the sweep as a null distribution or independent replication.

## Closing exercise — Build the battery register

Complete one register entry for each of the four families before reading `battery-register.json`. A strong entry names the claim, objection, condition, purpose, control address where applicable, stages traversed, executed configuration, warranted comparison, observed result, blind spot, bounded conclusion, and failure action.

The four lessons do not form a universal battery. They are examples of checks fitted to this fictional claim and data path. The first three are null-control families; the fourth is a sensitivity family.
