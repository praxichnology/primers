# Praxichnology Primer 01: Companion Materials

> **Synthetic instructional examples — no human participants, no research data, and no empirical evidence.**

This casebook is the worked-example companion to *Zeroing the Instrument: A Primer on Null-Control Batteries for Software-Based Measurement*. It turns the report's fictional *Garden Defense* examples into inspectable data files, guided exercises, and reproducible calculations.

The casebook is not evidence that a real game, construct, or measurement pipeline has been validated. It demonstrates how to state a claim, name an objection, construct a fitted check, calculate the warranted comparison, and stop at a bounded conclusion.

## Start here: reading does not require Python

Open **Zeroing the Instrument - Primer with Casebook - 091926.pdf** and go to **Appendix A**. The PDF is a separate download from the [Primer page](https://github.com/praxichnology/primers/tree/main/zeroing-the-instrument); if you have the complete package, it is in the parent folder. It contains the guided lessons and the worked answer key. Read the exercises first, then turn to the answers. You do not need to install or run anything to read the casebook.

The optional Python script is a calculator and consistency check. It does **not** create the casebook or a PDF, and it does not change the supplied data files. It prints the recomputed values in the terminal, followed by:

```text
Verified: all synthetic casebook calculations match their golden values.
```

A mismatch prints an error and returns a non-zero exit status. One example deliberately drops a record: a successful verification run confirms that this instructional failure is reproduced as declared; it does not certify that a real pipeline works.

## What is included

- `CASEBOOK - 091926.md` — guided lessons and questions.
- `data/00_two_toss_known_answer.json` — the report's exact two-toss demonstration.
- `data/01_distributional_control.json` — a generated-table distributional control.
- `data/02_label_permutation.json` — an exact label-permutation case.
- `data/03_enacted_no_mechanism.json` — a hand-auditable no-learning trace fixture.
- `data/03a_pipeline_known_answer.json` — a complete-record known-answer fixture.
- `data/03b_pipeline_dropped_record_failure.json` — a deliberately failing dropped-record fixture.
- `data/04_analyst_choice_sensitivity.json` — a prespecified cutoff-sensitivity case.
- `ANSWER_KEY - 091926.md` — worked calculations and bounded interpretations.
- `battery-register.json` — the four families in the report's register format.
- `expected-results.json` — golden values checked by the verification script.
- `verify_examples.py` — dependency-free reproduction of every reported number.
- `manifest.json` — package identity, contents, and verification entry point.

## Reproduce the answer key

From this directory, run:

```bash
python3 verify_examples.py
```

The script reads the source files, checks their provenance fields, recomputes every result, compares it with `expected-results.json`, and exits with a non-zero status if a value differs. A successful run means only that the casebook calculations reproduce their declared golden values.

## How to use the materials

1. Read the case brief and question in `CASEBOOK - 091926.md`.
2. Inspect the corresponding JSON before reading the answer.
3. Decide what comparison is warranted by the construction.
4. Run `verify_examples.py`.
5. Compare your interpretation with `ANSWER_KEY - 091926.md` and `battery-register.json`.

## Vocabulary and status

The package contains **three null-control families and one analyst-choice sensitivity family**. The sensitivity example is not a null control. The two-toss file is a known-answer demonstration rather than a fifth family. The `03a` and `03b` files are supporting pipeline fixtures rather than additional families.

Use these result labels:

- **Behaved as specified** — an implementation matched a derivable or prespecified expectation.
- **Requires investigation** — a verification check missed its warranted reference.
- **Characterized** — the check revealed the response of a stated condition without declaring that response correct or incorrect.
- **Not assessed** — the check did not traverse or represent the relevant part of the claim.

Do not convert these labels into a global “validated,” “certified,” or pass/fail badge for an instrument.

## Publication and citation

A Praxichnology Teaching Resource. These materials accompany **Praxichnology Primer 01**, September 19, 2026.

[Primer and downloads](https://github.com/praxichnology/primers/tree/main/zeroing-the-instrument) · [Zenodo concept DOI](https://doi.org/10.5281/zenodo.20371003)

Loh, C. S., & Sheng, Y. (2026). *Zeroing the instrument: A primer on null-control batteries for software-based measurement* (Praxichnology Primer 01). Zenodo. https://doi.org/10.5281/zenodo.20371003

The concept DOI opens the latest published Zenodo edition. Until the September 19 edition is deposited, it opens the earlier MEI-focused Primer.
